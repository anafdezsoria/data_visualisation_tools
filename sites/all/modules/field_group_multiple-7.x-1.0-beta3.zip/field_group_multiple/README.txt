DESCRIPTION
This module extends the Field group module by displays and widgets 
which group multiple fields by there items.
